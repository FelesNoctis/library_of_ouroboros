This is not a color friendly mod!  I tried to make it so no one but you would know what you were playing at.
You must choose full for the gloves, tights for the chest, pleated mini skirt with tights and the disco overlay.  you also need to choose tights for the boots.


The good thing is unless you are silly and call yourself Super girl or Kara or whatever no one shoudl ever report you!

The bad part is the costume  everyone else sees isn't going to win any awards....


You must choose black and white for all color options except for your head and the cape.  The cape IS color Friendly.  
In order for your skin to match the costume you should use the second row  third tone from the right on the skin color shart.


This Mod replaces :

Boot_V_Assassin_o1.texture
V_sf_hips_Disco_o1.texture
glove_stars.texture
chest_Desire.Texture
Cape_stars2_texture
Emblem_star_7.texture
Skirt_pleated_o1b.texture
Scanner_Hologram_bannerflipbook.texture
Scanner_Hologram_PPDLogoflipbook.texture

Simply put this file in a folder named Data in your COH directory and have fun!