This pack changes numerous power icons to be more descriptive of their powers' effects. To install, copy the "data" folder from this archive into the folder where your City of Heroes executable is saved. If for whatever reason you don't like a change this pack makes, you can revert individual icons by opening the "data" folder in the City of Heroes executable folder, and navigating through "texture_library" -> "GUI" -> "Icons" -> "Powers" to find the files for the custom icons, then deleting the file corresponding to the power icon you wish to revert.

Disclaimer: This pack was assembled assuming an i24 server. If you play on Homecoming, it may have unexpected effects on i25 power content, such as Sentinels. Additionally, the following documentation may be imcomplete; it's possible the pack may contain icons that don't do anything, don't appear on this list, or do appear on this list but aren't actually modified in-game. Lastly, the pack does not fix the following icon errors: Ally shields in Buff sets not having Targeted AoE borders; Ranged attacks such as Power Burst that got their range boosted as part of i24 still showing short-range blast inner symbols; Several "Build Up" style powers in newer sets, such as Street Justice, having a noticeable artifact in the inner symbol that isn't present in equivalent powers in older sets, such as Broad Sword.

Using this icon pack should have no affect on the stability of the game.

List of changes:

* Patron Pets given proper "Pet power" border, inner symbol changed to normal pet summon symbol 
-> Arachnos_Patron_SummonOnePet.texture


* Accolades/Crey CBX-9 Pistol (slash Stolen Immobilizer Ray) given proper single-target border
-> BA_Crey_Pistol.texture


* Archery/Rain of Arrows changed to have "extreme damage" symbol 
-> Archery_RainofArrows.texture


* Bane Spider Soldier/Poisonous Ray changed to have defense debuff symbol
-> BaneSpider_PoisonousRay.texture


* Bane Spider Soldier/Shatter changed to have "extreme damage" symbol
-> BaneSpider_Shatter.texture


* Bane Spider Training/Cloaking Device changed to have "invisibility" inner symbol
-> BaneSpiderTraining_CloakingDevice.texture


* Bane Spider Training/Surveillance changed to have defense debuff symbol
-> BaneSpiderTraining_Surveillance.texture


* Battle Axe/Taunt given proper Targeted AoE border
-> BattleAxe_Taunt.texture


* Body Mastery/Energy Torrent given "knockdown" symbol
-> BodyMastery_EnergyTorrent.texture


* Broadsword/Hack and Broadsword/Slash icons swapped to properly reflect relative strength of powers
-> Sword_Hack.texture
-> Sword_Slash.texture


* Claws/Swipe changed to have "melee minor damage" symbol
-> Claws_ClawsSwipe.texture


* Cold Domination/Heat Loss given "endurance drain" inner symbol
-> ColdDomination_HeatLoss.texture


* Cold Domination/Infrigidate inner symbol changed to indicate both -Speed and -Recharge
-> ColdDomination_Infrigidate.texture


* Cold Domination/Snow Storm inner symbol changed to indicate both -Speed and -Recharge
-> ColdDomination_SnowStorm.texture


* Cold Mastery/Flash Freeze given proper "sleep power" symbol
-> ColdMastery_FlashFreeze.texture


* Cold Mastery/Snow Storm changed to indicate both -Speed and -Recharge
-> ColdMastery_SnowStorm.texture


* Crab Spider Soldier/Longfang and Crab Spider Soldier/Channelgun icons swapped to properly reflect relative strengths of powers.
-> CrabSpider_Channelgun.texture
-> CrabSpider_Longfang.texture


* Dark Armor/Cloak of Darkness changed to accurately indicate the level of stealth it gives
-> DarkArmor_CloakOfDarkness.texture


* Dark Armor/Dark Embrace changed to have "smashing/lethal resistance" inner symbol
-> DarkArmor_DarkEmbrace.texture


* Dark Armor/Death Shroud changed to have "damage over time" inner symbol
-> DarkArmor_TouchOfDeath.texture


* Dark Armor/Hide inner symbol changed to "invisibility" symbol
-> DarkArmor_Stealth.texture


* Dark Armor/Obsidian Shield changed to have "mez protection power" symbol
-> DarkArmor_ObsidianShield.texture


* Dark Armor/Murky Cloud tweaked so icon indicates protection from both energy and negative energy
-> DarkArmor_DefractingCloud.texture


* Dark Blast/Dark Blast and Dark Blast/Gloom icons swapped to propery reflect relative strength of powers
-> DarkCast_DarkBlast.texture
-> DarkCast_SoulDrain.texture


* Dark Mastery/Dark Embrace changed to have "smashing/lethal protection" inner symbol
-> DarkMastery_DarkEmbrace.texture


* Dark Melee/Dark Consumption inner symbol changed to "boost endurance" symbol
-> ShadowFighting_DarkConsumption.texture


* Dark Melee/Shadow Maul changed to have "high damage" symbol
-> ShadowFighting_ShadowMaul.texture


* Dark Miasma/Shadow Fall inner symbol changed to more accurately indicate the level of stealth it grants
-> DarkMiasma_ShadowFall.texture


* Dark Miasma/Tar Patch given proper location AoE border
-> DarkMiasma_TarPatch.texture


* Day Jobs/Clubber changed to have proper "recovery boost" inner symbol
-> DayJob_RecoveryBoost.texture


* Day Jobs/Duelist changed to have "max endurance increase" inner symbol
-> DayJob_EnduranceBoost.texture


* Demon Summoning/Hell on Earth given combination single-target/summon border
-> DemonSummoning_HellonEarth.texture


* Earth Assault/Tremor given "knockdown" symbol
-> EarthAssault_Tremor.texture


* Earth Control/Animate Stone changed to have proper "pet summon" border
-> EarthGrasp_AnimateStone.texture


* Earth Control/Earthquake given "knockdown" symbol
-> EarthGrasp_Earthquake.texture


* Earth Control/Quicksand change to indicate -Speed instead of -Recharge
-> EarthGrasp_Quicksand.texture


* Electric Armor/Lightning Field given "damage over time" symbol
-> ElectricArmor_PBAoEMinorDamage.texture


* Electric Armor/Power Sink given "endurance drain" inner symbol
-> ElectricArmor_PBAoEEnduranceDrain.texture


* Electricity Assault/Charged Brawl given "moderate-damage melee" inner symbol
-> ElectricalAssault_ChargedBrawl.texture


* Electricity Assault/Havoc Punch given "high-damage melee" inner symbol
-> ElectricalAssault_HavocPunch.texture


* Electricity Assault/Thunder Strike given targeted AoE border
-> ElectricalAssault_Thunderstrike.texture


* Electric Control (all powers) changed from having the same color scheme as Electricity Assault to have its own unique purple and pink scheme. Also changed symbol of Jolting Chain to "chain" symbol, and symbol of Conductive Aura to "end drain" symbol.
-> ElectricControl_ChainFences.texture
-> ElectricControl_ElectricFence.texture
-> ElectricControl_Gremlins.texture
-> ElectricControl_JoltingChain.texture
-> ElectricControl_ParalyzingBlast.texture
-> ElectricControl_StaticField.texture
-> ElectricControl_StunningAura.texture
-> ElectricControl_SynapticOverload.texture
-> ElectricControl_TeslaCage.texture


* Electricity Manipulation/Charged Brawl given "moderate-damage melee" symbol
-> ElectricityManipulation_ChargedBrawl.texture


* Electricity Manipulation/Havok Punch given "high-damage melee" symbol
-> ElectricityManipulation_HavokPunch.texture


* Electricity Manipulation/Lightning Field given "damage over time" inner symbol
-> ElectricityManipulation_LightningField.texture


* Electricity Manipulation/Power Sink given "endurance drain" inner symbol
-> ElectricityManipulation_PowerSink.texture


* Electricity Manipulation/Thunderstrike changed to have proper targeted AoE border
-> ElectricityManipulation_ThunderStrike.texture


* Electric Melee/Lightning Rod given more descriptive "location AoE knockdown" icon
-> ElectricMelee_PBAoETeleport.texture


* Electric Melee/Taunt changed to have proper targeted AoE border
-> ElectricMelee_TargetedTaunt.texture


* Empathy/Adrenalin Boost inner symbol changed to "recharge buff" symbol
-> Empathy_AdrenalinBoost.texture


* Energy Assault/Total Focus changed to have more appropriate "extreme damage" symbol
-> EnergyAssault_TotalFocus.texture


* Energy Aura/Energy Drain given "endurance drain" inner symbol
-> EnergyAura_Drain.texture


* Energy Aura/Hide changed to have "invisibility" inner symbol
-> EnergyAura_Cloak.texture


* Energy Melee/Total Focus changed to have more appropriate "extreme damage" symbol
-> PowerPunch_TotalFocus.texture


* Energy Melee/Taunt changed to have proper targeted AoE border
-> PowerPunch_Taunt.texture


* Energy Manipulation/Stun given proper Disorient icon
-> EnergyManipulation_Stun.texture


* Energy Manipulation/Total Focus changed to have more appropriate more appropriate "Extreme Damage" symbol
-> EnergyManipulation_TotalFocus.texture


* Fiery Aura/Blazing Aura changed to have "damage over time" inner symbol
-> FlamingShield_FieryAura.texture


* Fiery Aura/Fire Shield changed to have "smashing/lethal protection" inner symbol
-> FlamingShield_FlamingShield.texture


* Fiery Melee/Taunt given proper Targeted AoE border
-> FieryFray_WillOWisp.texture


* Fire Blast/Rain of Fire given proper location AoE border
-> FireBlast_RainOfFire.texture


* Fire Control/Bonfire given proper location AoE border
-> FireTrap_Bonfire.texture


* Fire Control/Fire Imps given 3 pet summon symbol
-> FireTrap_FireImps.texture


* Fire Manipulation/Cauterizing Aura changed to have "damage over time" symbol
-> FireManipulation_BlazingAura.texture


* Fire Manipulation/Combustion given Fire Manipulation/Blazing Aura's old icon
-> FireManipulation_Combustion.texture


* Fire Manipulation/Fire Sword Circle given Fire Manpulation/Combustion's old icon
-> FireManipulation_FireSwordCircle.texture


* Fire Mastery/Fire Shield changed to have "smashing/lethal protection" inner symbol
-> FireMastery_FlamingShield.texture


* Flame Mastery/Bonfire given proper location AoE border
-> FlameMastery_Bonfire.texture


* Flame Mastery/Fire Shield changed to have "smashing/lethal protection" inner symbol
-> FlamingShield_FlamingShield.texture


* Flight/Air Superiority given "knockup" symbol, colors changed to match rest of pool
-> Flight_ArialAssault.texture


* Force Field/Detention Field changed to have "single-target phase shift" icon
-> ForceField_RefractionShield.texture


* Force Field/Repulsion Bomb given "knockdown" inner symbol
-> ForceField_RepulsionBomb.texture


* Force Mastery/Force of Nature changed to have "tier-9 defense power" symbol
-> ForceMastery_Unstoppable.texture


* Force Mastery/Repulsion Bomb given "knockdown" inner symbol
-> ForceField_RepulsionBomb.texture


* Fortunata Teamwork/Aura of Confusion given proper PBAoE border
-> FortunataTeamwork_AuraOfConfusion.texture


* Fortunata Teamwork/Mask Presence changed to have "invisibility" inner symbol
-> FortunataTeamwork_MaskPresence.texture


* Fortunata Teamwork/Tactical Training: Vengeance given "targeted AoE that only affects teammates" border
-> FortunataTeamwork_TacticalTrainingVengeance.texture


* Fortunata Training/Psychic Wail given "extreme damage" symbol
-> FortunataTraining_PsychicWail.texture


* Gravity Control/Dimension Shift given proper targeted AoE border
-> GravityControl_DimensionShift.texture


* Gravity Control/Wormhole given proper targeted AoE border, inner symbol changed to "teleport foe" symbol
-> GravityControl_Wormhole.texture


* Ice Armor/Chilling Embrace inner symbol changed to indicate both -Speed and -Recharge
-> IceArmor_ChillingEmbrace.texture


* Ice Armor/Glacial Armor tweaked so icon indicates defense to both energy and negative energy
-> IceArmor_GlacialArmor.texture


* Ice Armor/Hoarfrost changed to have same symbol as other HP-boosting powers
-> IceArmor_Hoarfrost.texture


* Ice Armor/Icicles given "damage over time" inner symbol
-> IceArmor_Icicles.texture


* Ice Blast/Blizzard given proper location AoE border
-> IceBlast_Blizzard.texture


* Ice Blast/Aim changed to have normal "Aim" icon to match Aim in other blast sets
-> IceBlast_Buildup.texture


* Ice Blast/Frost Breath inner symbol changed to indicate both -Speed and -Recharge
-> IceBlast_FrostBreath.texture


* Ice Blast/Ice Storm changed to have proper location AoE border and to have more appropriate "damage" icon
-> IceBlast_FreezingRain.texture


* Ice Control/Arctic Air icon changed to accurately reflect the effects of the power
-> IceFormation_ArticAir.texture


* Ice Control/Flash Freeze changed to have "sleep power" symbol
-> IceFormation_FlashFreeze.texture


* Ice Control/Ice Slick changed to have proper location AoE border, given "knockdown" symbol
-> IceFormation_IceSlick.texture


* Ice Manipulation/Frigid Protection inner symbol changed to more appropriate -Speed/-Recharge symbol
-> IceManipulation_ChillingEmbrace.texture


* Ice Manipulation/Frozen Aura changed to have "sleep power" symbol
-> IceManipulation_FrozenAura.texture


* Ice Manipulation/Ice Patch changed to have proper location AoE border, given "knockdown" symbol
-> IceManipulation_IcePatch.texture


* Ice Mastery/Ice Storm changed to have proper location AoE border and given "damage" symbol
-> IceMastery_FreezingRain.texture


* Ice Melee/Frozen Aura changed to have "sleep power" symbol
-> IcyOnslaught_FrozenAura.texture


* Ice Melee/Ice Patch changed to have proper location AoE border, given "knockdown" symbol
-> IcyOnslaught_IcePatch.texture


* Icy Assault/Chilling Embrace icon changed to indicate both -Speed and -Recharge
-> IceAssault_ChillingEmbrace.texture


* Inherent/Brawl changed to have "minor damage melee" inner symbol
-> Inherent_Brawl.texture


* Inherent/Shadow Recall changed to have proper single-target border, given "teleport teammate" inner symbol
-> InherentWarshade_ShadowRecall.texture


* Inherent/Walk icon inner symbol switched with less pixelated one
-> Inherent_Walk.texture


* Invulnerability/Unstoppable changed to have same icon as other defensive "tier 9" powers
-> Invulnerability_Unstoppable.texture


* Katana/Gambler's Cut and Katana/Sting of the Wasp icons swapped to properly reflect relative strength of powers
-> Katana_Hack.texture
-> Katana_Slash.texture


* Kinetic Melee (all powers) changed from having same color scheme as Kinetics to having their own, unique yellow scheme.  Also changed the symbols of the ST attacks to be more in line with other sets.
-> KineticAttack_AssassinsStrike.texture
-> KineticAttack_BodyBlow.texture
-> KineticAttack_Burst.texture
-> KineticAttack_Confront.texture
-> KineticAttack_FocusedBurst.texture
-> KineticAttack_Placate.texture
-> KineticAttack_PowerSiphon.texture
-> KineticAttack_QuickStrike.texture
-> KineticAttack_RepulsingTorrent.texture
-> KineticAttack_SmashingBlow.texture
-> KineticAttack_Taunt.texture
-> KineticAttack_TotalFocus.texture

* Kinetics/Increase Density given "grant ally mez protection" inner symbol
-> KineticBoost_IncreaseDensity.texture


* Kinetics/Inertial Reduction changed to have proper PBAoE border
-> KineticBoost_InitialReductions.texture


* Kinetics/Transference changed to have targeted AoE border and to have "endurance boost" inner symbol to more closely communicate the effects of the power
-> KineticBoost_Transferance.texture


* Kinetics/Transfusion changed to have targeted AoE border to more closely communicate the effects of the power
-> KineticBoost_Transfusion.texture


* Leadership/Vengeance changed to have "targeted AoE that only works on teammates" border
-> Leadership_Vengence.texture


* Leviathan Mastery/Water Spout changed to have proper location AoE border
-> Arachnos_Patron_DropKnockback.texture


* Luminous Aura/Conserve Energy changed to have "boost endurance" inner symbol
-> LuminousAura_ConserveEnergy.texture


* Luminous Aura/Light Form changed to have same symbol as other "tier 9 defense" powers
-> LuminousAura_LightForm.texture


* Luminous Blast/Photon Seekers changed to have "summon 3 pets" inner symbol
-> LuminousBlast_PhotonSeekers.texture


* Mercenaries/Burst changed to have "light damage ranged" inner symbol
-> Paramilitary_AssaultRifleBurst.texture


* Mercenaries/Equip Mercenary given targeted AoE border
-> Paramilitary_EquipSoldier.texture


* Mercenaries/Slug changed to have "moderate damage ranged" inner symbol
-> Paramilitary_AssaultRifleSlug.texture


* Mercenaries/Tactical Upgrade given targeted AoE border
-> Paramilitary_TacticalUpgrade.texture


* Mind Control/Telekinesis changed to have proper targeted AoE border, and given "repel power" symbol
-> MentalControl_Telekinesis.texture


* Munitions Mastery/Body Armor changed to have "smashing/lethal protection" inner symbol
-> MunitionsMastery_BodyArmor.texture


* Munitions Mastery/Surveillance changed to have defense debuff symbol
-> MunitionsMastery_Surveillance.texture


* Necromancy/Dark Blast icon changed to have "light damage ranged" symbol
-> Necromancy_DarkBlast.texture


* Necromancy/Dark Empowerment given targeted AoE border
-> Necromancy_DarkEmpowerment.texture


* Necromancy/Enchant Undead givent targeted AoE border
-> Necromancy_EnchantUndead.texture


* Necromancy/Gloom changed to have "moderate damage ranged" symbol
-> Necromancy_Gloom.texture


* Night Widow Training/Slash changed to have "extreme damage" symbol
-> NightWidowTraining_Slash.texture


* Ninjas/Aimed Shot changed to have "moderate damage ranged" inner symbol
-> Ninjas_StandardShot.texture


* Ninjas/Kuji-In Zen given targeted AoE border
-> Ninjas_UpgradeEquipment.texture


* Ninjas/Snap Shot icon changed to have "light damage ranged" inner symbol
-> Ninjas_QuickShot.texture


* Ninjas/Train Ninjas given targeted AoE border
-> Ninjas_TrainNinjas.texture


* Ninjitsu/Hide inner symbol changed to "invisibility" symbol
-> Ninjitsu_Hide.texture


* Pain Domination/Painbringer inner symbol changed to "damage buff" symbol
-> PainDomination_Painbringer.texture


* Pain Domination/Soothing Aura changed to have "PBAoE regeneration increase" icon (not perfectly accurate, but accurate 3 times out of 4 when you include the next power on the list)
-> PainDomination_SoothingAura.texture


* Pain Domination/Suppress Pain changed to have "PBAoE regeneration increase" icon
-> PainDomination_SoothingAura.texture


* Pain Domination/World of Pain changed to have "only affects teammates" border, given "offense and defense buff" inner symbol
-> PainDomination_WorldOfPain.texture


* Plant Control/Carrion Creepers changed to have proper location AoE border, inner symbol changed to "many pets" symbol
-> PlantControl_CarrionCreeper.texture


* Plant Control/Spirit Tree changed to have proper "regeneration buff" inner symbol
-> PlantControl_SpiritTree.texture


* Poison/Antidote changed to have proper single-target border and given "grant ally mez protection" symbol
-> Poison_Antidote.texture


* Poison/Neurotoxic Breath changed to indicate both -Speed and -Recharge
-> Poison_NeurotoxicBreath.texture


* Poison/Noxious Gas colors changed to match rest of set
-> Poison_NoxiousGas.texture


* Presence/Provoke changed to have proper targeted AoE border
-> Manipulation_Provoke.texture


* Psychic Blast/Psychic Wail changed to have same symbol as other nukes
-> PsychicBlast_PsychicWail.texture


* Radiation Emission/EM Pulse given "endurance drain" inner symbol
-> RadiationPoisoning_EMPPulse.texture


* Radiation Emission/Fallout changed to have proper targeted AoE border and have "corpse bomb" symbol
-> RadiationPoisoning_Fallout.texture


* Radiation Emission/Mutation changed to have proper single-target border
-> RadiationPoisoning_Mutation.texture


* Radiation Emission/Radiation Infection and Radiation Emission/Enervating Field icons swapped (they erroneously described each other's effects rather than their own)
-> RadiationPoisoning_RadiationInfection.texture
-> RadiationPoisoning_EnervatingField.texture


* Regeneration/Hide inner symbol changed to "invisibility" symbol
-> Regeneration_Hide.texture


* Robotics/Equip Robot given targeted AoE border
-> Robotics_EquipRobot.texture


* Robotics/Pulse Rifle Blast changed to have "light damage ranged" inner symbol
-> Robotics_LaserRifleBurst.texture


* Robotics/Pulse Rifle Burst changed to have "moderate damage ranged" inner symbol
-> Robotics_LaserRifleBlast.texture


* Robotics/Upgrade Robot given targeted AoE border
-> Robotics_UpgradeRobot.texture


* Shield Defense/Shield Charge changed to more descriptive "location AoE knockdown" icon
-> ShieldDefense_ShieldCharge.texture


* Sonic Resonance/Liquefy given "knockdown" symbol
-> SonicDebuff_DropKnockback.texture


* Sonic Resonance/Sonic Cage given "phase shift" inner symbol
-> SonicDebuff_Hold.texture


* Sonic Resonance/Sonic Dispersion given "damage resistance" inner symbol
-> SonicDebuff_BuffDamageRes.texture


* Spines/Quills given a symbol that more accurately reflects the amount of damage it does
-> Quills_Quills.texture


* Stone Armor/Crystal Armor tweaked so icon indicates defense to both energy and negative energy damage
-> StoneArmor_CrystalArmor.texture


* Stone Armor/Rooted changed to remove the PBAoE border
-> StoneArmor_Rooted.texture


* Stone Armor/Mudpots changed so icon indicates -Spd instead of -Recharge
-> StoneArmor_Clay.texture


* Stone Melee/Fault given "knockdown" symbol
-> StoneMelee_Fault.texture


* Stone Melee/Taunt changed to have proper targeted AoE border
-> StoneMelee_Taunt.texture


* Stone Melee/Tremor given "knockdown" symbol
-> StoneMelee_Tremor.texture


* Storm Summoning/Freezing Rain given location AoE border
-> StormSummoning_FreezingRain.texture


* Storm Summoning/Snow Storm changed to indicate both -Speed and -Recharge
-> StormSummoning_SnowStorm.texture


* Storm Summoning/Steamy Mist changed to have proper PBAoE border
-> StormSummoning_Fog.texture


* Storm Summoning/Tornado changed to have knockback icon
-> StormSummoning_Tornado.texture


* Super Reflexes/Hide inner symbol changed to "invisibility" symbol
-> SuperReflexes_Hide.texture


* Super Speed/Whirlwind changed to have appropriate knockback symbol
-> SuperSpeed_Whirlwind.texture


* Super Strength/Foot Stomp given "knockdown" symbol
-> SuperStrength_FootStomp.texture


* Super Strength/Hurl icon changed to properly show the amount of range the power has
-> SuperStrength_Hurl.texture


* Super Strength/Jab inner symbol changed to "light damage melee" symbol
-> SuperStrength_Jab.texture


* Super Strength/Taunt changed to have proper targeted AoE border
-> SuperStrength_Taunt.texture


* Teamwork/Indomitable Will changed to have "mez protection" symbol
-> Teamwork_IndomitableWill.texture


* Teleportation/Team Teleport changed to have proper teammate-only PBAoE border
-> Teleportation_GroupTeleport.texture


* Temporary Pet Powers (all of them; Warwolf, Shivan, Vial of Bees, etc.) given standard pet summon inner symbol
-> Temporary_WarWolfWhistle.texture


* Temporary Powers/Apprentice Charm color changed to "inherent powers" color scheme
-> Temporary_TargetedDebuffDefense.texture


* Temporary Powers/Chemical Burn changed to have proper location AoE border
-> Temporary_Warburg_DebuffDefense.texture


* Temporary Powers/Endurance Increase changed to have "max endurance increase" inner symbol
-> Temporary_Mayhem_SelfBuffEnd.texture


* Temporary Powers/Ghostslayer Bomb given proper targeted AoE border
-> Temporary_GhostlayerBomb.texture


* Temporary Powers/Health Increase changed to have "max HP increase" inner symbol
-> Temporary_Mayhem_SelfHeal.texture


* Temporary Powers/Mutagen color changed to "inherent powers" color scheme
-> Temporary_TargetedDebuffDamage.texture


* Temporary Powers/Nuclear Blast changed to have proper location AoE border
-> Temporary_Warburg_MassiveDamage.texture


* Temporary Powers/Power Analyzer (all "marks") changed to have "reticle" inner symbol
-> Temporary_PowerAnalyzer.texture


* Temporary Powers/Recovery Serum changed to have "recovery buff" symbol
-> Temporary_SelfRecoveryBuff.texture


* Temporary Powers/Taser Dart color changed to "inherent powers" color scheme
-> Temporary_TargetedHold.texture


* Temporary Powers/Throwing Knives color changed to "inherent powers" color scheme
-> Temporary_TargetedDoT.texture
-> [b]Note! This changes the icon for the Envenomed Dagger temporary power too![/b]


* Temporary Powers/Tranq Dart color changed to "inherent powers" color scheme
-> Temporary_TargetedSleep.texture


* Temporary Powers/Summon Teammates given teammate-only PBAoE border
-> Temporary_Mayhem_TargetAoETeleportTeamToCaster.texture


* Temporary Powers/Web Grenade (and Fettering Nimbus) given proper single-target border
-> Temporary_FetteringNimbus.texture


* Thermal Radiation/Thaw inner symbol changed to "grant ally mez protection" symbol
-> ThermalRadiation_Thaw.texture


* Thugs/Dual Wield changed to have "moderate damage ranged" inner symbol
-> Thugs_TargetedRangedHeavyDmg.texture


* Thugs/Equip Thugs given targeted AoE border
-> Thugs_EquipThugs.texture


* Thugs/Upgrade Equipment given targeted AoE border
-> Thugs_UpgradeEquipment.texture


* Training and Gadgets/Combat Training: Defensive change to have ranged defense symbol
-> TrainingandGadgets_CombatTrainingDefensive.texture


* Traps/Detonator changed to have more appropriate targeted AoE border
-> Traps_AoEMassiveDamage.texture


* Trick Arrow/EMP Arrow colors changed to match rest of set and to have appropriate "hold" symbol
-> TrickArrow_Stun.texture


* Trick Arrow/Glue Arrow changed to have combination "location AoE"/targeted AoE border, and inner symbol changed to indicate -Speed
-> TrickArrow_Slow.texture


* Trick Arrow/Oil Slick Arrow colors changed to match rest of set and given location AoE border
-> TrickArrow_Knockdown.texture


* Umbral Aura/Eclipse given "endurance drain" inner symbol
-> UmbralAura_Eclipse.texture


* Umbral Aura/Orbiting Death changed to have "damage over time" inner symbol
-> UmbralAura_OrbitingDeath.texture


* Umbral Aura/Stygian Return PBAoE border removed
-> UmbralAura_StygianReturn.texture


* Umbral Blast/Dark Extraction changed to have "recycle corpse to make new pet" inner symbol
-> UmbralBlast_DarkExtraction.texture


* Veteran/Assemble the Team given "teammate-only PBAoE" border
-> Veteran_TargetAoETeleportTeamToCaster.texture


* Veteran/Base Transporter colors changed to match the rest of the Veteran Power icons
-> Veteran_TeleportBase.texture


* Veteran/Reveal inner symbol changed to VidiotMaps logo as tribute to VidiotMaps
-> Veteran_Reveal.texture


* War Mace/Taunt changed to have proper targeted AoE border
-> Mace_Taunt.texture


* Widow Teamwork/Mask Presence changed to have "invisibility" inner symbol
-> WidowTeamwork_MaskPresence.texture


* Widow Teamwork/Tactical Training: Vengeance given "targeted AoE that only affects teammates" border
-> WidowTeamwork_TacticalTrainingVengeance.texture


* Widow Training/Dart Burst given ranged attack symbol
-> WidowTraining_DartBurst.texture


* Widow Training/Strike given "moderate damage melee" symbol
-> WidowTraining_Strike.texture


* Widow Training/Lunge given "damage" symbol
-> WidowTraining_Lunge.texture


* Willpower/Heightened Senses given general "defense" symbol
-> Willpower_HeightenedSenses.texture


* Willpower/Hide inner symbol changed to "invisibility" symbol
-> Willpower_Hide.texture


* Willpower/High Pain Tolerance changed to have "HP buff" icon
-> Willpower_HighPainTolerance.texture


* Willpower/Indomitable Will changed to have "mez protection power" icon
-> Willpower_IndomitableWill.texture


* Willpower/Strength of Will changed to have same symbol as other defensive "tier 9" powers
-> Willpower_StrengthOfWill.texture