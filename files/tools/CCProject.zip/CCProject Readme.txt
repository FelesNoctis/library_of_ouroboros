Character Creator Project version 1.0
By "Element" at www.cohguru.com

---
Description
---

A project to incorporate all sorts of new costume pieces into the stand-alone Character Creator.

Info and link to the stand-alone Character Creator can be found in this thread: http://www.cohguru.com/forum/showthread.php?t=5971

This is an early version of the project and there are numerous problems with it at its current state, but it works for the most part.

---
Installation
---

1). Unzip the data folder to your stand-alone Character Creator directory.

2). Copy over the following files from your City of Heroes' piggs folder to your Character Creator's piggs folder:

texPlayersUI.pigg
texVEnemies.pigg
texEnemies.pigg
texEnemies2.pigg
texEnemies3.pigg
texEnemies4.pigg
texEnemies5.pigg

If you do not copy over these texture archives, you will get alot of blank white costume pieces though it will still load.

Also, do not copy over any of CoH's geometry archives (geom.pigg and the sort) to CC. It will crash.

---
Features
---

-Access to numerous NPC-only costume pieces
-Access to DVD Edition / PreOrder costume pieces -- chest details, capes, and helmets.
-Access to older "removed" costume pieces

---
Known Issues
---

-Huge doesn't have any of the NPC-only pieces unlocked, and Female shows some of the NPC-only costume pieces meant for Huge.
-Huge also doesn't have access to DVD/PreOrder chest details and helmets, but strangely has access to the capes.
-There are alot of costume pieces that did not carry over from the original CoH modification.
-Due to geometry version differences, some of the face textures end up skewed (a la Citadel).
-All costume pieces are "decategorized". This makes the Gloves and Boots lists very long.

---
Notes
---

-Alot of the headgear ends up in Hats.
-Most of the new pieces end up at the bottom of the list they're in.
-Do not attempt to load City of Heroes with the modified list.

---
Version History
---

1.0
-Initial release